
ele_demo
========
仿【饿了么】订餐软件的一个demo
==========

[ele_demo]（https://github.com/tigerguixh/ele_demo）

 demo里包含的常用ui控件有
1.带阻尼回弹效果----ScrollView

2.下拉刷新----RefreshableListView

3.带section和header的ListVIew ----StickyListHeadersListView

4.虚线----DashedLineView

5.购物车常用的显示数量----BadgeView（有添加购物车的动画效果）

6.两列面板（menu和content）的切换 ----SlidingPaneLayout

7.自带清除输入文字的EditTextView----ClearEditTextView

8.可能是最好用的图片加载控件----universal-image-loader

9.fragment，webview，selector等其他细节布局控件的使用

==========
 ![image](https://github.com/guxun12/file_temp/blob/master/ele_demo/homeShow.gif)
 ![image](https://github.com/guxun12/file_temp/blob/master/ele_demo/restaurantShow.gif)
 
=
后续会添加地图定位，图片滤镜等功能

[黑客帝国字符效果](https://github.com/racaljk/verbatimAnim)

个人网站源码,实现了类似黑客帝国字符逐个显示的效果

具体效果请参见http://racaljk.github.io/verbatimAnim/

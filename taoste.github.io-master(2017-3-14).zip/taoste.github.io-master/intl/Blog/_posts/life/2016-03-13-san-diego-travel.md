---
layout: post
title: San Diego 自驾游
category: 生活
tags: essay
keywords: 加州,圣地亚哥,生活,California,San Diego
---

> San Diego 就在 Los Angeles 车程不到2小时的地方，本来是来 LA 以后首选的旅行城市，拖到现在才去。总的说来，这个城市不大，每个地方都很容易到达，特别适合生活。

<iframe src="https://www.google.com/maps/d/u/0/embed?mid=1i4ygqIUA64JFqT8JCkdKUciF4go" width="640" height="480"></iframe>

## Carlsbad Flower Fields

![Carlsbad Flower Fields](http://7u2ho6.com1.z0.glb.clouddn.com/life-carlsbad-flower-fields.png)

## University of California San Diego

![University of San Diego](http://7u2ho6.com1.z0.glb.clouddn.com/life-university-of-san-diego.png)

## San Diego Temple

![San Diego Temple](http://7u2ho6.com1.z0.glb.clouddn.com/life-san-diego-temple.png)

## La Jolla Cove

![La Jolla Cove](http://7u2ho6.com1.z0.glb.clouddn.com/life-la-jolla-cove.png)

## SeaWorld

![SeaWorld](http://7u2ho6.com1.z0.glb.clouddn.com/life-seaworld-san-diego.png)

## USS Midway Museum

![USS Midway Museum](http://7u2ho6.com1.z0.glb.clouddn.com/life-uss-midway-museum.png)

![Cute girl](http://7u2ho6.com1.z0.glb.clouddn.com/life-cute-girl.png)

## Sunset Cliffs Park

![Sunset Cliffs Park](http://7u2ho6.com1.z0.glb.clouddn.com/life-sunset-cliffs-park.png)

## Old Town

![Old Town](http://7u2ho6.com1.z0.glb.clouddn.com/life-old-town.png)

## Potato Chip Rock

![Potato Chip Rock](http://7u2ho6.com1.z0.glb.clouddn.com/life-potato-chip-rock.png)

## 美食严重推荐

- Great Plaza Buffet


- 返回[[wiki首页]] (https://github.com/taoste/taoste.github.io/blob/master/README.wiki)
- 返回[[web主站]] (https://taoste.github.io)

== 关注微信==

- 如果想进一步了解我，请扫描下方<B>微信二维码</B>（QRcode）即可关注。
&copy;[Taoste](https://zh.wikipedia.org/wiki/User:Taoste)

<img src="/images/choong-logo.png" width="200" height="200"><img src="/images/qrcode.jpg" width="200" height="200">

----------------

<B>[慕课网:《HTML+CSS基础课程》](http://www.imooc.com/learn/9) </B>- 认识<img>标签，为网页插入图片 http://www.imooc.com/code/318

<p><B>语法:</B></p>
<pre><code>
< img src="图片地址" alt="下载失败时的替换文本" title = "提示文本"  width="800" height="600" / >
</code></pre>

<p><B>举例:</B></p>
<img src="./images/shengshi.png" alt="shengshi" title = "shengshi"  width="1024" height="768" /> 

== 美图赏析 ==

<img src="/images/mm.jpg"/>
